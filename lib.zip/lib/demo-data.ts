// Demo data for VendorConnect platform

export interface ItemCategory {
  id: string
  name: string
  icon: string
  description: string
  subcategories: string[]
}

export interface ShopLocation {
  id: string
  name: string
  address: string
  city: string
  state: string
  coordinates: {
    lat: number
    lng: number
  }
  distance?: number
  rating: number
  isVerified: boolean
  categories: string[]
  phone: string
  businessHours: string
}

export interface Product {
  id: string
  name: string
  price: number
  unit: string
  minOrder: number
  stock: number
  description: string
  category: string
  subcategory: string
  shopId: string
  shopName: string
  isAvailable: boolean
  image?: string
  tags: string[]
}

export interface Order {
  id: string
  vendorId: string
  vendorName: string
  vendorPhone: string
  vendorAddress: string
  supplierId: string
  supplierName: string
  supplierPhone: string
  products: Array<{
    id: string
    name: string
    quantity: number
    price: number
    unit: string
  }>
  totalAmount: number
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled'
  orderDate: string
  estimatedDelivery: string
  actualDelivery?: string
  deliveryAddress: string
  paymentStatus: 'pending' | 'paid' | 'failed'
  trackingNumber?: string
  notes?: string
}

// Item Categories
export const itemCategories: ItemCategory[] = [
  {
    id: 'food',
    name: 'Food Items',
    icon: '🍽️',
    description: 'Fresh food ingredients and prepared items',
    subcategories: ['vegetables', 'fruits', 'grains', 'dairy', 'meat', 'seafood', 'bakery', 'snacks']
  },
  {
    id: 'clothes',
    name: 'Clothing & Textiles',
    icon: '👕',
    description: 'Fabric, clothing materials, and accessories',
    subcategories: ['cotton', 'silk', 'wool', 'synthetic', 'accessories', 'uniforms']
  },
  {
    id: 'snacks',
    name: 'Snacks & Beverages',
    icon: '🍿',
    description: 'Ready-to-eat snacks and drinks',
    subcategories: ['chips', 'nuts', 'beverages', 'candies', 'biscuits', 'energy-drinks']
  },
  {
    id: 'drinks',
    name: 'Beverages',
    icon: '🥤',
    description: 'Hot and cold beverages',
    subcategories: ['tea', 'coffee', 'juices', 'soft-drinks', 'energy-drinks', 'water']
  },
  {
    id: 'spices',
    name: 'Spices & Condiments',
    icon: '🌶️',
    description: 'Cooking spices and condiments',
    subcategories: ['whole-spices', 'ground-spices', 'masalas', 'sauces', 'pickles']
  },
  {
    id: 'equipment',
    name: 'Kitchen Equipment',
    icon: '🔧',
    description: 'Cooking and serving equipment',
    subcategories: ['cookware', 'utensils', 'appliances', 'serving-items', 'storage']
  },
  {
    id: 'packaging',
    name: 'Packaging Materials',
    icon: '📦',
    description: 'Food packaging and serving materials',
    subcategories: ['containers', 'wrappers', 'bags', 'boxes', 'cups', 'plates']
  },
  {
    id: 'other',
    name: 'Other Items',
    icon: '📋',
    description: 'Miscellaneous items and supplies',
    subcategories: ['cleaning', 'safety', 'decorations', 'seasonal', 'custom']
  }
]

// Shop Locations (Mumbai area)
export const shopLocations: ShopLocation[] = [
  {
    id: '1',
    name: 'Fresh Foods Supply Co.',
    address: 'Shop No. 15, Crawford Market',
    city: 'Mumbai',
    state: 'Maharashtra',
    coordinates: { lat: 18.9296, lng: 72.8335 },
    rating: 4.8,
    isVerified: true,
    categories: ['food', 'vegetables', 'fruits', 'dairy'],
    phone: '+91 98765 43210',
    businessHours: '6:00 AM - 8:00 PM'
  },
  {
    id: '2',
    name: 'Spice Paradise',
    address: 'Unit 23, Dadar Market',
    city: 'Mumbai',
    state: 'Maharashtra',
    coordinates: { lat: 19.0170, lng: 72.8478 },
    rating: 4.6,
    isVerified: true,
    categories: ['spices', 'condiments', 'masalas'],
    phone: '+91 98765 43211',
    businessHours: '7:00 AM - 9:00 PM'
  },
  {
    id: '3',
    name: 'Dairy Delights',
    address: 'Shop 8, Bandra Market',
    city: 'Mumbai',
    state: 'Maharashtra',
    coordinates: { lat: 19.0596, lng: 72.8295 },
    rating: 4.9,
    isVerified: true,
    categories: ['dairy', 'milk', 'cheese', 'yogurt'],
    phone: '+91 98765 43212',
    businessHours: '5:00 AM - 10:00 PM'
  },
  {
    id: '4',
    name: 'Snack Corner',
    address: 'Ground Floor, Andheri Station',
    city: 'Mumbai',
    state: 'Maharashtra',
    coordinates: { lat: 19.1197, lng: 72.8464 },
    rating: 4.4,
    isVerified: true,
    categories: ['snacks', 'beverages', 'chips', 'nuts'],
    phone: '+91 98765 43213',
    businessHours: '8:00 AM - 11:00 PM'
  },
  {
    id: '5',
    name: 'Beverage Hub',
    address: 'Shop 12, Juhu Beach Road',
    city: 'Mumbai',
    state: 'Maharashtra',
    coordinates: { lat: 19.0990, lng: 72.8295 },
    rating: 4.3,
    isVerified: false,
    categories: ['drinks', 'beverages', 'juices', 'soft-drinks'],
    phone: '+91 98765 43214',
    businessHours: '9:00 AM - 10:00 PM'
  },
  {
    id: '6',
    name: 'Kitchen Equipment Store',
    address: 'Unit 45, Sion Market',
    city: 'Mumbai',
    state: 'Maharashtra',
    coordinates: { lat: 19.0170, lng: 72.8578 },
    rating: 4.7,
    isVerified: true,
    categories: ['equipment', 'cookware', 'utensils'],
    phone: '+91 98765 43215',
    businessHours: '8:00 AM - 8:00 PM'
  },
  {
    id: '7',
    name: 'Packaging Solutions',
    address: 'Shop 33, Vashi Market',
    city: 'Navi Mumbai',
    state: 'Maharashtra',
    coordinates: { lat: 19.0760, lng: 72.9987 },
    rating: 4.5,
    isVerified: true,
    categories: ['packaging', 'containers', 'wrappers'],
    phone: '+91 98765 43216',
    businessHours: '7:00 AM - 7:00 PM'
  },
  {
    id: '8',
    name: 'Textile Traders',
    address: 'Shop 67, Dadar Market',
    city: 'Mumbai',
    state: 'Maharashtra',
    coordinates: { lat: 19.0170, lng: 72.8478 },
    rating: 4.2,
    isVerified: false,
    categories: ['clothes', 'cotton', 'silk', 'uniforms'],
    phone: '+91 98765 43217',
    businessHours: '9:00 AM - 8:00 PM'
  }
]

// Products
export const products: Product[] = [
  // Food Items
  {
    id: '1',
    name: 'Fresh Tomatoes',
    price: 40,
    unit: 'kg',
    minOrder: 5,
    stock: 100,
    description: 'Fresh red tomatoes from local farms',
    category: 'food',
    subcategory: 'vegetables',
    shopId: '1',
    shopName: 'Fresh Foods Supply Co.',
    isAvailable: true,
    tags: ['fresh', 'organic', 'local']
  },
  {
    id: '2',
    name: 'Onions',
    price: 25,
    unit: 'kg',
    minOrder: 10,
    stock: 200,
    description: 'Quality onions for your recipes',
    category: 'food',
    subcategory: 'vegetables',
    shopId: '1',
    shopName: 'Fresh Foods Supply Co.',
    isAvailable: true,
    tags: ['fresh', 'bulk']
  },
  {
    id: '3',
    name: 'Garam Masala',
    price: 180,
    unit: 'kg',
    minOrder: 1,
    stock: 50,
    description: 'Premium garam masala blend',
    category: 'spices',
    subcategory: 'ground-spices',
    shopId: '2',
    shopName: 'Spice Paradise',
    isAvailable: true,
    tags: ['premium', 'authentic']
  },
  {
    id: '4',
    name: 'Red Chili Powder',
    price: 120,
    unit: 'kg',
    minOrder: 2,
    stock: 75,
    description: 'Hot red chili powder',
    category: 'spices',
    subcategory: 'ground-spices',
    shopId: '2',
    shopName: 'Spice Paradise',
    isAvailable: true,
    tags: ['hot', 'spicy']
  },
  {
    id: '5',
    name: 'Fresh Milk',
    price: 60,
    unit: 'liter',
    minOrder: 5,
    stock: 100,
    description: 'Pure cow milk',
    category: 'food',
    subcategory: 'dairy',
    shopId: '3',
    shopName: 'Dairy Delights',
    isAvailable: true,
    tags: ['fresh', 'pure', 'daily']
  },
  {
    id: '6',
    name: 'Paneer',
    price: 200,
    unit: 'kg',
    minOrder: 1,
    stock: 30,
    description: 'Fresh homemade paneer',
    category: 'food',
    subcategory: 'dairy',
    shopId: '3',
    shopName: 'Dairy Delights',
    isAvailable: true,
    tags: ['fresh', 'homemade']
  },
  {
    id: '7',
    name: 'Potato Chips',
    price: 80,
    unit: 'packet',
    minOrder: 10,
    stock: 150,
    description: 'Crispy potato chips',
    category: 'snacks',
    subcategory: 'chips',
    shopId: '4',
    shopName: 'Snack Corner',
    isAvailable: true,
    tags: ['crispy', 'popular']
  },
  {
    id: '8',
    name: 'Mixed Nuts',
    price: 300,
    unit: 'kg',
    minOrder: 2,
    stock: 40,
    description: 'Premium mixed nuts',
    category: 'snacks',
    subcategory: 'nuts',
    shopId: '4',
    shopName: 'Snack Corner',
    isAvailable: true,
    tags: ['premium', 'healthy']
  },
  {
    id: '9',
    name: 'Orange Juice',
    price: 120,
    unit: 'liter',
    minOrder: 3,
    stock: 60,
    description: 'Fresh orange juice',
    category: 'drinks',
    subcategory: 'juices',
    shopId: '5',
    shopName: 'Beverage Hub',
    isAvailable: true,
    tags: ['fresh', 'natural']
  },
  {
    id: '10',
    name: 'Cooking Pan',
    price: 800,
    unit: 'piece',
    minOrder: 1,
    stock: 25,
    description: 'Non-stick cooking pan',
    category: 'equipment',
    subcategory: 'cookware',
    shopId: '6',
    shopName: 'Kitchen Equipment Store',
    isAvailable: true,
    tags: ['non-stick', 'durable']
  },
  {
    id: '11',
    name: 'Food Containers',
    price: 150,
    unit: 'piece',
    minOrder: 5,
    stock: 80,
    description: 'Plastic food containers',
    category: 'packaging',
    subcategory: 'containers',
    shopId: '7',
    shopName: 'Packaging Solutions',
    isAvailable: true,
    tags: ['plastic', 'reusable']
  },
  {
    id: '12',
    name: 'Cotton Fabric',
    price: 120,
    unit: 'meter',
    minOrder: 10,
    stock: 200,
    description: 'Pure cotton fabric',
    category: 'clothes',
    subcategory: 'cotton',
    shopId: '8',
    shopName: 'Textile Traders',
    isAvailable: true,
    tags: ['pure', 'breathable']
  }
]

// Mock Orders
export const mockOrders: Order[] = [
  {
    id: '1',
    vendorId: 'vendor1',
    vendorName: 'Rajesh Chaat Corner',
    vendorPhone: '+91 9130050207',
    vendorAddress: 'Shop 12, Andheri West, Mumbai',
    supplierId: '1',
    supplierName: 'Fresh Foods Supply Co.',
    supplierPhone: '+91 98765 43210',
    products: [
      { id: '1', name: 'Fresh Tomatoes', quantity: 10, price: 40, unit: 'kg' }
    ],
    totalAmount: 400,
    status: 'delivered',
    orderDate: '2024-01-15',
    estimatedDelivery: '2024-01-16',
    actualDelivery: '2024-01-16',
    deliveryAddress: 'Shop 12, Andheri West, Mumbai',
    paymentStatus: 'paid'
  },
  {
    id: '2',
    vendorId: 'vendor1',
    vendorName: 'Rajesh Chaat Corner',
    vendorPhone: '+91 9130050207',
    vendorAddress: 'Shop 12, Andheri West, Mumbai',
    supplierId: '2',
    supplierName: 'Spice Paradise',
    supplierPhone: '+91 98765 43211',
    products: [
      { id: '3', name: 'Garam Masala', quantity: 2, price: 180, unit: 'kg' }
    ],
    totalAmount: 360,
    status: 'shipped',
    orderDate: '2024-01-20',
    estimatedDelivery: '2024-01-22',
    deliveryAddress: 'Shop 12, Andheri West, Mumbai',
    paymentStatus: 'paid',
    trackingNumber: 'TRK123456789'
  }
]

// Helper functions
export const getProductsByCategory = (category: string): Product[] => {
  return products.filter(product => product.category === category)
}

export const getProductsByShop = (shopId: string): Product[] => {
  return products.filter(product => product.shopId === shopId)
}

export const getNearbyShops = (userLat: number, userLng: number, radius: number = 10): ShopLocation[] => {
  return shopLocations
    .map(shop => ({
      ...shop,
      distance: calculateDistance(userLat, userLng, shop.coordinates.lat, shop.coordinates.lng)
    }))
    .filter(shop => shop.distance <= radius)
    .sort((a, b) => (a.distance || 0) - (b.distance || 0))
}

export const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
  const R = 6371 // Earth's radius in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLng = (lng2 - lng1) * Math.PI / 180
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng/2) * Math.sin(dLng/2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
  return R * c
}

export const getCategoryIcon = (categoryId: string): string => {
  const category = itemCategories.find(cat => cat.id === categoryId)
  return category?.icon || '📦'
}

export const getCategoryName = (categoryId: string): string => {
  const category = itemCategories.find(cat => cat.id === categoryId)
  return category?.name || 'Other'
} 