// SMS Service for VendorConnect
// This is a simulated SMS service that can be easily replaced with real SMS providers

export interface SMSMessage {
  to: string
  from: string
  body: string
}

export interface OrderSMSData {
  orderId: string
  vendorName: string
  vendorPhone: string
  supplierName: string
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered'
  totalAmount: number
  estimatedDelivery?: string
  products: Array<{
    name: string
    quantity: number
    price: number
  }>
}

class SMSService {
  private apiKey: string
  private fromNumber: string

  constructor() {
    // In production, these would come from environment variables
    this.apiKey = process.env.SMS_API_KEY || 'demo-key'
    this.fromNumber = process.env.SMS_FROM_NUMBER || '+91 9130050207'
  }

  async sendSMS(message: SMSMessage): Promise<boolean> {
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      // Log the SMS for demonstration
      console.log('📱 SMS Sent:', {
        to: message.to,
        from: message.from,
        body: message.body,
        timestamp: new Date().toISOString()
      })

      // In production, you would integrate with a real SMS service like:
      // - Twilio
      // - AWS SNS
      // - MessageBird
      // - Vonage (formerly Nexmo)

      return true
    } catch (error) {
      console.error('SMS sending failed:', error)
      return false
    }
  }

  // Send order status update to vendor
  async sendOrderStatusUpdate(data: OrderSMSData): Promise<boolean> {
    const message = this.formatOrderStatusMessage(data)
    
    return this.sendSMS({
      to: data.vendorPhone,
      from: this.fromNumber,
      body: message
    })
  }

  // Send order confirmation to supplier
  async sendOrderConfirmationToSupplier(data: OrderSMSData): Promise<boolean> {
    const message = this.formatOrderConfirmationMessage(data)
    
    return this.sendSMS({
      to: data.vendorPhone, // In real app, this would be supplier's phone
      from: this.fromNumber,
      body: message
    })
  }

  private formatOrderStatusMessage(data: OrderSMSData): string {
    const baseMessage = `VendorConnect: Order #${data.orderId}`
    
    switch (data.status) {
      case 'pending':
        return `${baseMessage} has been received and is being processed. Total: ₹${data.totalAmount}`
      
      case 'confirmed':
        return `${baseMessage} has been confirmed by ${data.supplierName}. Estimated delivery: ${data.estimatedDelivery}. Total: ₹${data.totalAmount}`
      
      case 'shipped':
        return `${baseMessage} has been shipped by ${data.supplierName} and is on its way to you. Track your order on VendorConnect.`
      
      case 'delivered':
        return `${baseMessage} has been delivered successfully! Thank you for choosing VendorConnect. Rate your experience.`
      
      default:
        return `${baseMessage} status updated to ${data.status}.`
    }
  }

  private formatOrderConfirmationMessage(data: OrderSMSData): string {
    const productList = data.products.map(p => `${p.name} (${p.quantity})`).join(', ')
    
    return `VendorConnect: New order #${data.orderId} received from ${data.vendorName}. Products: ${productList}. Total: ₹${data.totalAmount}. Please confirm within 2 hours.`
  }

  // Send welcome message to new users
  async sendWelcomeMessage(phone: string, name: string, role: 'vendor' | 'supplier'): Promise<boolean> {
    const message = `Welcome to VendorConnect, ${name}! Your ${role} account has been created successfully. Start connecting and growing your business today!`
    
    return this.sendSMS({
      to: phone,
      from: this.fromNumber,
      body: message
    })
  }

  // Send verification code
  async sendVerificationCode(phone: string, code: string): Promise<boolean> {
    const message = `VendorConnect: Your verification code is ${code}. Valid for 10 minutes. Do not share this code with anyone.`
    
    return this.sendSMS({
      to: phone,
      from: this.fromNumber,
      body: message
    })
  }

  // Send low stock alert to supplier
  async sendLowStockAlert(phone: string, productName: string, currentStock: number): Promise<boolean> {
    const message = `VendorConnect: Low stock alert! ${productName} is running low (${currentStock} units remaining). Please restock soon to avoid order cancellations.`
    
    return this.sendSMS({
      to: phone,
      from: this.fromNumber,
      body: message
    })
  }

  // Send delivery reminder to vendor
  async sendDeliveryReminder(phone: string, orderId: string, estimatedDelivery: string): Promise<boolean> {
    const message = `VendorConnect: Reminder! Your order #${orderId} is scheduled for delivery on ${estimatedDelivery}. Please ensure someone is available to receive the order.`
    
    return this.sendSMS({
      to: phone,
      from: this.fromNumber,
      body: message
    })
  }
}

// Export singleton instance
export const smsService = new SMSService()

// Example usage functions
export const sendOrderNotification = async (orderData: OrderSMSData) => {
  return smsService.sendOrderStatusUpdate(orderData)
}

export const sendWelcomeNotification = async (phone: string, name: string, role: 'vendor' | 'supplier') => {
  return smsService.sendWelcomeMessage(phone, name, role)
}

export const sendVerificationNotification = async (phone: string, code: string) => {
  return smsService.sendVerificationCode(phone, code)
} 