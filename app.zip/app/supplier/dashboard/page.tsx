'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Package, 
  Truck, 
  CheckCircle, 
  Clock, 
  AlertCircle,
  Plus,
  Edit,
  Trash2,
  Phone,
  MessageSquare,
  TrendingUp,
  DollarSign,
  ShoppingBag,
  LogOut,
  User,
  Building,
  MapPin,
  Star,
  Settings,
  Store,
  Camera,
  Save,
  X,
  Eye,
  EyeOff,
  Bell,
  Calendar,
  BarChart3,
  Users,
  CreditCard
} from 'lucide-react'
import { useRouter } from 'next/navigation'
import toast from 'react-hot-toast'
import { smsService } from '../../../lib/sms'
import { mockOrders, products, shopLocations } from '../../../lib/demo-data'

interface Order {
  id: string
  vendorId: string
  vendorName: string
  vendorPhone: string
  vendorAddress: string
  supplierId: string
  supplierName: string
  supplierPhone: string
  products: Array<{
    id: string
    name: string
    quantity: number
    price: number
    unit: string
  }>
  totalAmount: number
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled'
  orderDate: string
  estimatedDelivery: string
  actualDelivery?: string
  deliveryAddress: string
  paymentStatus: 'pending' | 'paid' | 'failed'
  trackingNumber?: string
  notes?: string
}

interface Product {
  id: string
  name: string
  price: number
  unit: string
  minOrder: number
  stock: number
  description: string
  category: string
  subcategory: string
  shopId: string
  shopName: string
  isAvailable: boolean
  image?: string
  tags: string[]
}

interface ShopInfo {
  id: string
  name: string
  address: string
  city: string
  state: string
  phone: string
  businessHours: string
  description: string
  categories: string[]
  isVerified: boolean
  rating: number
}

export default function SupplierDashboard() {
  const [user, setUser] = useState<any>(null)
  const [orders, setOrders] = useState<Order[]>([])
  const [myProducts, setMyProducts] = useState<Product[]>([])
  const [shopInfo, setShopInfo] = useState<ShopInfo | null>(null)
  const [showAddProduct, setShowAddProduct] = useState(false)
  const [showEditProduct, setShowEditProduct] = useState<Product | null>(null)
  const [showShopSetup, setShowShopSetup] = useState(false)
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [activeTab, setActiveTab] = useState<'orders' | 'products' | 'shop' | 'analytics'>('orders')
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  // Mock shop data
  const mockShopInfo: ShopInfo = {
    id: '1',
    name: 'Fresh Foods Supply Co.',
    address: 'Shop No. 15, Crawford Market',
    city: 'Mumbai',
    state: 'Maharashtra',
    phone: '+91 98765 43210',
    businessHours: '6:00 AM - 8:00 PM',
    description: 'Premium supplier of fresh vegetables and dairy products',
    categories: ['food', 'vegetables', 'fruits', 'dairy'],
    isVerified: true,
    rating: 4.8
  }

  useEffect(() => {
    // Check if user is logged in
    const currentUser = localStorage.getItem('currentUser')
    if (!currentUser) {
      router.push('/supplier/login')
      return
    }
    
    const userData = JSON.parse(currentUser)
    setUser(userData)
    
    // Load shop info - try to get from localStorage first, then use mock data
    const storedShopData = localStorage.getItem('shopData')
    if (storedShopData) {
      const shopData = JSON.parse(storedShopData)
      setShopInfo(shopData)
      
      // Load my products (filtered by shop ID)
      const myShopProducts = products.filter(product => product.shopId === shopData.id)
      setMyProducts(myShopProducts)
      
      // Load orders for this supplier
      const myOrders = mockOrders.filter(order => order.supplierId === shopData.id)
      setOrders(myOrders)
    } else {
      // Fallback to mock shop data
      setShopInfo(mockShopInfo)
      
      // Load my products (filtered by shop ID)
      const myShopProducts = products.filter(product => product.shopId === mockShopInfo.id)
      setMyProducts(myShopProducts)
      
      // Load orders for this supplier
      const myOrders = mockOrders.filter(order => order.supplierId === mockShopInfo.id)
      setOrders(myOrders)
    }
  }, [router])

  const updateOrderStatus = async (orderId: string, newStatus: Order['status']) => {
    setIsLoading(true)
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    setOrders(orders.map(order =>
      order.id === orderId ? { ...order, status: newStatus } : order
    ))

    const order = orders.find(o => o.id === orderId)
    if (order) {
      // Send SMS notification
      await sendSMSNotification(order, newStatus)
      toast.success(`Order status updated to ${newStatus}`)
    }
    
    setIsLoading(false)
  }

  const sendSMSNotification = async (order: Order, status: string) => {
    try {
      const message = getSMSMessage(order, status)
      console.log('SMS sent to', order.vendorPhone, ':', message)
      
      // Use the SMS service
      await smsService.sendSMS({
        to: order.vendorPhone,
        from: '+91 9130050207',
        body: message
      })
      
      toast.success('SMS notification sent to vendor!')
    } catch (error) {
      toast.error('Failed to send SMS notification')
    }
  }

  const getSMSMessage = (order: Order, status: string) => {
    const baseMessage = `VendorConnect: Order #${order.id} from ${order.vendorName}`
    
    switch (status) {
      case 'confirmed':
        return `${baseMessage} has been confirmed. Estimated delivery: ${order.estimatedDelivery}. Total: ₹${order.totalAmount}. Thank you for choosing VendorConnect!`
      case 'shipped':
        return `${baseMessage} has been shipped and is on its way. Track your order on VendorConnect. Expected delivery: ${order.estimatedDelivery}.`
      case 'delivered':
        return `${baseMessage} has been delivered successfully! Thank you for choosing VendorConnect. Please rate your experience.`
      default:
        return `${baseMessage} status updated to ${status}.`
    }
  }

  const addProduct = (productData: Omit<Product, 'id' | 'shopId' | 'shopName'>) => {
    const newProduct: Product = {
      ...productData,
      id: Date.now().toString(),
      shopId: shopInfo?.id || '1',
      shopName: shopInfo?.name || 'My Shop'
    }
    setMyProducts([...myProducts, newProduct])
    setShowAddProduct(false)
    toast.success('Product added successfully!')
  }

  const createSampleProducts = () => {
    if (!shopInfo) return
    
    const sampleProducts: Omit<Product, 'id' | 'shopId' | 'shopName'>[] = [
      {
        name: 'Sample Product 1',
        price: 100,
        unit: 'kg',
        minOrder: 5,
        stock: 50,
        description: 'This is a sample product. Please edit with your actual product details.',
        category: 'food',
        subcategory: 'vegetables',
        isAvailable: true,
        tags: ['sample', 'new']
      },
      {
        name: 'Sample Product 2',
        price: 150,
        unit: 'piece',
        minOrder: 10,
        stock: 100,
        description: 'Another sample product. Update with your real product information.',
        category: 'snacks',
        subcategory: 'chips',
        isAvailable: true,
        tags: ['sample', 'popular']
      }
    ]
    
    const newProducts = sampleProducts.map(product => ({
      ...product,
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      shopId: shopInfo.id,
      shopName: shopInfo.name
    }))
    
    setMyProducts([...myProducts, ...newProducts])
    toast.success('Sample products added! Please edit them with your actual product details.')
  }

  const updateProduct = (productId: string, updates: Partial<Product>) => {
    setMyProducts(myProducts.map(product =>
      product.id === productId ? { ...product, ...updates } : product
    ))
    setShowEditProduct(null)
    toast.success('Product updated successfully!')
  }

  const deleteProduct = (productId: string) => {
    setMyProducts(myProducts.filter(product => product.id !== productId))
    toast.success('Product deleted successfully!')
  }

  const updateShopInfo = (updates: Partial<ShopInfo>) => {
    if (shopInfo) {
      setShopInfo({ ...shopInfo, ...updates })
      toast.success('Shop information updated successfully!')
    }
  }

  const logout = () => {
    localStorage.removeItem('currentUser')
    router.push('/')
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-600 bg-yellow-100'
      case 'confirmed': return 'text-blue-600 bg-blue-100'
      case 'shipped': return 'text-purple-600 bg-purple-100'
      case 'delivered': return 'text-green-600 bg-green-100'
      case 'cancelled': return 'text-red-600 bg-red-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="h-4 w-4" />
      case 'confirmed': return <CheckCircle className="h-4 w-4" />
      case 'shipped': return <Truck className="h-4 w-4" />
      case 'delivered': return <CheckCircle className="h-4 w-4" />
      case 'cancelled': return <AlertCircle className="h-4 w-4" />
      default: return <Clock className="h-4 w-4" />
    }
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gradient">VendorConnect</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Building className="h-5 w-5 text-gray-600" />
                <span className="text-sm font-medium text-gray-700">{shopInfo?.name}</span>
                {shopInfo?.isVerified && (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                )}
              </div>
              
              <button
                onClick={logout}
                className="p-2 text-gray-600 hover:text-red-600"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-white p-6 rounded-lg shadow-sm"
          >
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 rounded-lg">
                <ShoppingBag className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Orders</p>
                <p className="text-2xl font-semibold text-gray-900">{orders.length}</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="bg-white p-6 rounded-lg shadow-sm"
          >
            <div className="flex items-center">
              <div className="p-2 bg-green-100 rounded-lg">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Revenue</p>
                <p className="text-2xl font-semibold text-gray-900">
                  ₹{orders.reduce((sum, order) => sum + order.totalAmount, 0)}
                </p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="bg-white p-6 rounded-lg shadow-sm"
          >
            <div className="flex items-center">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <Package className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Products</p>
                <p className="text-2xl font-semibold text-gray-900">{myProducts.length}</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="bg-white p-6 rounded-lg shadow-sm"
          >
            <div className="flex items-center">
              <div className="p-2 bg-purple-100 rounded-lg">
                <DollarSign className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Pending Orders</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {orders.filter(order => order.status === 'pending').length}
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-white rounded-lg shadow-sm mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'orders', label: 'Orders', icon: ShoppingBag },
                { id: 'products', label: 'Products', icon: Package },
                { id: 'shop', label: 'Shop Info', icon: Store },
                { id: 'analytics', label: 'Analytics', icon: BarChart3 }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-primary-500 text-primary-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <tab.icon className="h-5 w-5 mr-2" />
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          {activeTab === 'orders' && (
            <motion.div
              key="orders"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white rounded-lg shadow-sm p-6"
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-semibold text-gray-900">Recent Orders</h3>
                <span className="text-sm text-gray-600">{orders.length} orders</span>
              </div>

              <div className="space-y-4">
                {orders.map((order) => (
                  <motion.div
                    key={order.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h4 className="font-medium text-gray-900">{order.vendorName}</h4>
                        <p className="text-sm text-gray-600">Order #{order.id}</p>
                        <p className="text-sm text-gray-600">{order.orderDate}</p>
                        <p className="text-sm text-gray-600">{order.vendorAddress}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center ${getStatusColor(order.status)}`}>
                          {getStatusIcon(order.status)}
                          <span className="ml-1">{order.status}</span>
                        </span>
                      </div>
                    </div>

                    <div className="mb-3">
                      <p className="text-sm text-gray-600">
                        {order.products.map(p => `${p.name} (${p.quantity} ${p.unit})`).join(', ')}
                      </p>
                      <p className="font-semibold text-gray-900">₹{order.totalAmount}</p>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="text-sm text-blue-600 hover:text-blue-700 flex items-center"
                        >
                          <MessageSquare className="h-4 w-4 mr-1" />
                          Send SMS
                        </button>
                        <a
                          href={`tel:${order.vendorPhone}`}
                          className="text-sm text-green-600 hover:text-green-700 flex items-center"
                        >
                          <Phone className="h-4 w-4 mr-1" />
                          Call
                        </a>
                      </div>

                      <div className="flex space-x-2">
                        {order.status === 'pending' && (
                          <>
                            <button
                              onClick={() => updateOrderStatus(order.id, 'confirmed')}
                              disabled={isLoading}
                              className="px-3 py-1 bg-blue-500 text-white text-xs rounded hover:bg-blue-600 disabled:opacity-50"
                            >
                              Confirm
                            </button>
                            <button
                              onClick={() => updateOrderStatus(order.id, 'shipped')}
                              disabled={isLoading}
                              className="px-3 py-1 bg-purple-500 text-white text-xs rounded hover:bg-purple-600 disabled:opacity-50"
                            >
                              Ship
                            </button>
                          </>
                        )}
                        {order.status === 'confirmed' && (
                          <button
                            onClick={() => updateOrderStatus(order.id, 'shipped')}
                            disabled={isLoading}
                            className="px-3 py-1 bg-purple-500 text-white text-xs rounded hover:bg-purple-600 disabled:opacity-50"
                          >
                            Ship
                          </button>
                        )}
                        {order.status === 'shipped' && (
                          <button
                            onClick={() => updateOrderStatus(order.id, 'delivered')}
                            disabled={isLoading}
                            className="px-3 py-1 bg-green-500 text-white text-xs rounded hover:bg-green-600 disabled:opacity-50"
                          >
                            Mark Delivered
                          </button>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}



// Ensure props like: activeTab, myProducts, createSampleProducts, setShowAddProduct, setShowEditProduct, deleteProduct are passed or declared above.

{activeTab === 'products' && (
  <motion.div
    key="products"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    className="bg-white rounded-lg shadow-sm p-6"
  >
    <div className="flex justify-between items-center mb-6">
      <h3 className="text-lg font-semibold text-gray-900">Products</h3>
      <div className="flex space-x-3">
        {myProducts.length === 0 && (
          <button
            onClick={createSampleProducts}
            className="btn-outline text-sm py-2 px-4 flex items-center"
          >
            <Package className="h-4 w-4 mr-1" />
            Add Sample Products
          </button>
        )}
        <button
          onClick={() => setShowAddProduct(true)}
          className="btn-secondary text-sm py-2 px-4 flex items-center"
        >
          <Plus className="h-4 w-4 mr-1" />
          Add Product
        </button>
      </div>
    </div>

    {myProducts.length === 0 ? (
      <div className="col-span-full text-center py-12">
        <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h4 className="text-lg font-medium text-gray-900 mb-2">No Products Yet</h4>
        <p className="text-gray-600 mb-6">
          Start by adding your first product or create sample products to get started.
        </p>
        <div className="flex justify-center space-x-3">
          <button onClick={createSampleProducts} className="btn-outline">
            <Package className="h-4 w-4 mr-1" />
            Add Sample Products
          </button>
          <button onClick={() => setShowAddProduct(true)} className="btn-primary">
            <Plus className="h-4 w-4 mr-1" />
            Add Your First Product
          </button>
        </div>
      </div>
    ) : (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {myProducts.map((product) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="border rounded-lg p-4 hover:shadow-md transition-shadow"
          >
            <div className="flex justify-between items-start mb-2">
              <div className="flex-1">
                <h4 className="font-medium text-gray-900">{product.name}</h4>
                <p className="text-sm text-gray-600">{product.description}</p>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => setShowEditProduct(product)}
                  className="text-blue-600 hover:text-blue-700"
                >
                  <Edit className="h-4 w-4" />
                </button>
                <button
                  onClick={() => deleteProduct(product.id)}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm mb-3">
              <div>
                <span className="text-gray-600">Price:</span>
                <span className="font-medium ml-1">₹{product.price}/{product.unit}</span>
              </div>
              <div>
                <span className="text-gray-600">Stock:</span>
                <span className="font-medium ml-1">{product.stock} {product.unit}</span>
              </div>
              <div>
                <span className="text-gray-600">Min Order:</span>
                <span className="font-medium ml-1">{product.minOrder} {product.unit}</span>
              </div>
              <div>
                <span className="text-gray-600">Category:</span>
                <span className="font-medium ml-1 capitalize">{product.category}</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-1">
              {(product.tags || []).map((tag, i) => (
                <span
                  key={`${product.id}-tag-${i}`}
                  className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded"
                >
                  {tag}
                </span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    )}
  </motion.div>
)}


          {activeTab === 'shop' && (
            <motion.div
              key="shop"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white rounded-lg shadow-sm p-6"
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-semibold text-gray-900">Shop Information</h3>
                <button
                  onClick={() => setShowShopSetup(true)}
                  className="btn-secondary text-sm py-2 px-4 flex items-center"
                >
                  <Edit className="h-4 w-4 mr-1" />
                  Edit Shop
                </button>
              </div>

              {shopInfo && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Basic Information</h4>
                    <div className="space-y-2 text-sm">
                      <div>
                        <span className="text-gray-600">Shop Name:</span>
                        <span className="font-medium ml-2">{shopInfo.name}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Address:</span>
                        <span className="font-medium ml-2">{shopInfo.address}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">City:</span>
                        <span className="font-medium ml-2">{shopInfo.city}, {shopInfo.state}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Phone:</span>
                        <span className="font-medium ml-2">{shopInfo.phone}</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Business Details</h4>
                    <div className="space-y-2 text-sm">
                      <div>
                        <span className="text-gray-600">Business Hours:</span>
                        <span className="font-medium ml-2">{shopInfo.businessHours}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Rating:</span>
                        <span className="font-medium ml-2 flex items-center">
                          <Star className="h-4 w-4 text-yellow-400 mr-1" />
                          {shopInfo.rating}
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-600">Status:</span>
                        <span className="font-medium ml-2 flex items-center">
                          {shopInfo.isVerified ? (
                            <>
                              <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
                              Verified
                            </>
                          ) : (
                            <>
                              <Clock className="h-4 w-4 text-yellow-500 mr-1" />
                              Pending Verification
                            </>
                          )}
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-600">Categories:</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {shopInfo.categories.map((category: string) => (
                            <span key={category} className="px-2 py-1 bg-primary-100 text-primary-700 text-xs rounded">
                              {category}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'analytics' && (
            <motion.div
              key="analytics"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white rounded-lg shadow-sm p-6"
            >
              <h3 className="text-lg font-semibold text-gray-900 mb-6">Analytics Dashboard</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-center">
                    <Users className="h-8 w-8 text-blue-600" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-blue-600">Total Customers</p>
                      <p className="text-2xl font-bold text-blue-900">
                        {new Set(orders.map(o => o.vendorId)).size}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center">
                    <TrendingUp className="h-8 w-8 text-green-600" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-green-600">Monthly Revenue</p>
                      <p className="text-2xl font-bold text-green-900">
                        ₹{orders.reduce((sum, order) => sum + order.totalAmount, 0)}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-yellow-50 p-4 rounded-lg">
                  <div className="flex items-center">
                    <Package className="h-8 w-8 text-yellow-600" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-yellow-600">Active Products</p>
                      <p className="text-2xl font-bold text-yellow-900">
                        {myProducts.filter(p => p.isAvailable).length}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-purple-50 p-4 rounded-lg">
                  <div className="flex items-center">
                    <CreditCard className="h-8 w-8 text-purple-600" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-purple-600">Pending Payments</p>
                      <p className="text-2xl font-bold text-purple-900">
                        ₹{orders.filter(o => o.paymentStatus === 'pending').reduce((sum, order) => sum + order.totalAmount, 0)}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* SMS Modal */}
      <AnimatePresence>
        {selectedOrder && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-lg p-6 max-w-md w-full mx-4"
            >
              <h3 className="text-lg font-semibold mb-4">Send SMS Notification</h3>
              <p className="text-gray-600 mb-4">
                Send SMS to {selectedOrder.vendorName} about order #{selectedOrder.id}
              </p>
              
              <div className="space-y-3">
                <button
                  onClick={() => {
                    sendSMSNotification(selectedOrder, selectedOrder.status)
                    setSelectedOrder(null)
                  }}
                  className="w-full btn-secondary"
                >
                  Send Status Update
                </button>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="w-full btn-outline"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Product Modal */}
      <AnimatePresence>
        {showAddProduct && (
          <AddProductModal 
            onClose={() => setShowAddProduct(false)}
            onAdd={addProduct}
          />
        )}
      </AnimatePresence>

      {/* Edit Product Modal */}
      <AnimatePresence>
        {showEditProduct && (
          <EditProductModal 
            product={showEditProduct}
            onClose={() => setShowEditProduct(null)}
            onUpdate={updateProduct}
          />
        )}
      </AnimatePresence>
    </div>
  )
}

// Add Product Modal Component
function AddProductModal({ onClose, onAdd }: { 
  onClose: () => void
  onAdd: (productData: Omit<Product, 'id' | 'shopId' | 'shopName'>) => void 
}) {
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    unit: '',
    minOrder: '',
    stock: '',
    description: '',
    category: '',
    subcategory: '',
    tags: '',
    isAvailable: true
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    const productData = {
      name: formData.name,
      price: parseFloat(formData.price),
      unit: formData.unit,
      minOrder: parseFloat(formData.minOrder),
      stock: parseFloat(formData.stock),
      description: formData.description,
      category: formData.category,
      subcategory: formData.subcategory,
      tags: formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag),
      isAvailable: formData.isAvailable
    }
    
    onAdd(productData)
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto"
      >
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-semibold">Add New Product</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Product Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="Enter product name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Price *
              </label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={formData.price}
                onChange={(e) => setFormData({...formData, price: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="0.00"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Unit *
              </label>
              <select
                required
                value={formData.unit}
                onChange={(e) => setFormData({...formData, unit: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              >
                <option value="">Select unit</option>
                <option value="kg">Kilogram (kg)</option>
                <option value="liter">Liter</option>
                <option value="piece">Piece</option>
                <option value="packet">Packet</option>
                <option value="meter">Meter</option>
                <option value="dozen">Dozen</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Minimum Order *
              </label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={formData.minOrder}
                onChange={(e) => setFormData({...formData, minOrder: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="0.00"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Stock Available *
              </label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={formData.stock}
                onChange={(e) => setFormData({...formData, stock: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="0.00"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category *
              </label>
              <select
                required
                value={formData.category}
                onChange={(e) => setFormData({...formData, category: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              >
                <option value="">Select category</option>
                <option value="food">Food Items</option>
                <option value="clothes">Clothing & Textiles</option>
                <option value="snacks">Snacks & Beverages</option>
                <option value="drinks">Beverages</option>
                <option value="spices">Spices & Condiments</option>
                <option value="equipment">Kitchen Equipment</option>
                <option value="packaging">Packaging Materials</option>
                <option value="other">Other Items</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Subcategory
            </label>
            <input
              type="text"
              value={formData.subcategory}
              onChange={(e) => setFormData({...formData, subcategory: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              placeholder="e.g., vegetables, dairy, etc."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description *
            </label>
            <textarea
              required
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              placeholder="Describe your product..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Tags (comma-separated)
            </label>
            <input
              type="text"
              value={formData.tags}
              onChange={(e) => setFormData({...formData, tags: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              placeholder="fresh, organic, local, etc."
            />
          </div>

          <div className="flex items-center">
            <input
              type="checkbox"
              id="isAvailable"
              checked={formData.isAvailable}
              onChange={(e) => setFormData({...formData, isAvailable: e.target.checked})}
              className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
            />
            <label htmlFor="isAvailable" className="ml-2 block text-sm text-gray-900">
              Product is available for sale
            </label>
          </div>

          <div className="flex space-x-3 pt-4">
            <button
              type="submit"
              className="flex-1 bg-primary-600 text-white py-2 px-4 rounded-lg hover:bg-primary-700 transition-colors"
            >
              Add Product
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  )
}

// Edit Product Modal Component
function EditProductModal({ product, onClose, onUpdate }: { 
  product: Product
  onClose: () => void
  onUpdate: (productId: string, updates: Partial<Product>) => void 
}) {
  const [formData, setFormData] = useState({
    name: product.name,
    price: product.price.toString(),
    unit: product.unit,
    minOrder: product.minOrder.toString(),
    stock: product.stock.toString(),
    description: product.description,
    category: product.category,
    subcategory: product.subcategory,
    tags: product.tags.join(', '),
    isAvailable: product.isAvailable
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    const updates = {
      name: formData.name,
      price: parseFloat(formData.price),
      unit: formData.unit,
      minOrder: parseFloat(formData.minOrder),
      stock: parseFloat(formData.stock),
      description: formData.description,
      category: formData.category,
      subcategory: formData.subcategory,
      tags: formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag),
      isAvailable: formData.isAvailable
    }
    
    onUpdate(product.id, updates)
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto"
      >
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-semibold">Edit Product</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Product Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="Enter product name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Price *
              </label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={formData.price}
                onChange={(e) => setFormData({...formData, price: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="0.00"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Unit *
              </label>
              <select
                required
                value={formData.unit}
                onChange={(e) => setFormData({...formData, unit: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              >
                <option value="">Select unit</option>
                <option value="kg">Kilogram (kg)</option>
                <option value="liter">Liter</option>
                <option value="piece">Piece</option>
                <option value="packet">Packet</option>
                <option value="meter">Meter</option>
                <option value="dozen">Dozen</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Minimum Order *
              </label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={formData.minOrder}
                onChange={(e) => setFormData({...formData, minOrder: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="0.00"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Stock Available *
              </label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={formData.stock}
                onChange={(e) => setFormData({...formData, stock: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="0.00"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category *
              </label>
              <select
                required
                value={formData.category}
                onChange={(e) => setFormData({...formData, category: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              >
                <option value="">Select category</option>
                <option value="food">Food Items</option>
                <option value="clothes">Clothing & Textiles</option>
                <option value="snacks">Snacks & Beverages</option>
                <option value="drinks">Beverages</option>
                <option value="spices">Spices & Condiments</option>
                <option value="equipment">Kitchen Equipment</option>
                <option value="packaging">Packaging Materials</option>
                <option value="other">Other Items</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Subcategory
            </label>
            <input
              type="text"
              value={formData.subcategory}
              onChange={(e) => setFormData({...formData, subcategory: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              placeholder="e.g., vegetables, dairy, etc."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description *
            </label>
            <textarea
              required
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              placeholder="Describe your product..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Tags (comma-separated)
            </label>
            <input
              type="text"
              value={formData.tags}
              onChange={(e) => setFormData({...formData, tags: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              placeholder="fresh, organic, local, etc."
            />
          </div>

          <div className="flex items-center">
            <input
              type="checkbox"
              id="isAvailable"
              checked={formData.isAvailable}
              onChange={(e) => setFormData({...formData, isAvailable: e.target.checked})}
              className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
            />
            <label htmlFor="isAvailable" className="ml-2 block text-sm text-gray-900">
              Product is available for sale
            </label>
          </div>

          <div className="flex space-x-3 pt-4">
            <button
              type="submit"
              className="flex-1 bg-primary-600 text-white py-2 px-4 rounded-lg hover:bg-primary-700 transition-colors"
            >
              Update Product
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  )
} 