import { NextRequest, NextResponse } from 'next/server'
import { smsService, OrderSMSData } from '@/lib/sms'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, data } = body

    let success = false

    switch (type) {
      case 'order_status_update':
        success = await smsService.sendOrderStatusUpdate(data as OrderSMSData)
        break
      
      case 'order_confirmation':
        success = await smsService.sendOrderConfirmationToSupplier(data as OrderSMSData)
        break
      
      case 'welcome_message':
        const { phone, name, role } = data
        success = await smsService.sendWelcomeMessage(phone, name, role)
        break
      
      case 'verification_code':
        const { phone: vPhone, code } = data
        success = await smsService.sendVerificationCode(vPhone, code)
        break
      
      case 'low_stock_alert':
        const { phone: sPhone, productName, currentStock } = data
        success = await smsService.sendLowStockAlert(sPhone, productName, currentStock)
        break
      
      case 'delivery_reminder':
        const { phone: dPhone, orderId, estimatedDelivery } = data
        success = await smsService.sendDeliveryReminder(dPhone, orderId, estimatedDelivery)
        break
      
      default:
        return NextResponse.json(
          { error: 'Invalid SMS type' },
          { status: 400 }
        )
    }

    if (success) {
      return NextResponse.json({ 
        success: true, 
        message: 'SMS sent successfully' 
      })
    } else {
      return NextResponse.json(
        { error: 'Failed to send SMS' },
        { status: 500 }
      )
    }

  } catch (error) {
    console.error('SMS API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'VendorConnect SMS API',
    version: '1.0.0',
    endpoints: {
      'POST /api/sms': 'Send SMS notifications',
      types: [
        'order_status_update',
        'order_confirmation', 
        'welcome_message',
        'verification_code',
        'low_stock_alert',
        'delivery_reminder'
      ]
    }
  })
} 